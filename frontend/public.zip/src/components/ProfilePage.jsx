import React from 'react';
import Navbar from './Navbar'

const ProfilePage = () => {
  return (
    <>
    <Navbar/>
    <div style={{ padding: "2rem", textAlign: "center", color: "white" }}>
      <h2>Profile Page</h2>
      <p>Comimng soon...</p>
    </div>
    </>
  );
};

export default ProfilePage;
